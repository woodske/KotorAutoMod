///// Knights of the Old Republic: HD Pazaak Cards /////
Author: CarthOnasty
Version: 1.0
Contact: Find me on http://deadlystream.com.


///// 01. Intro /////

Pazaak! The game whose name I misspell nearly every time I type it. Anyway, the cards are looking pretty dated these days so here’s a higher resolution version.


///// 02. Background /////

These actually started as a much larger project (that I fully intend to finish), but since I had the cards done, I figured I might as well release them.


///// 03. Install /////

Drag 'em to your override folder. These shouldn't conflict with anything. Note: For those of you who prefer the green cards from TSL, you’ll find that variant in the “green” folder. Just overwrite the originals.


///// 04. Uninstall /////

Remove the files.


///// 05. Disclaimer /////

Distribute, have fun, edit, whatever. I only ask that you don't claim this as your own.


///// 06. Thanks /////

ebmar, DarthParametric, Sith Holocron, Kexikus, JCarter426, djh269, A Future Pilot, LDR